<!DOCTYPE html>
<html>
<head>
    <title>Data Tenan Restoran Puja Sera</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style type="text/css">
        body{
            padding: 50px;
            background: #f2f5f2;
        }
    </style>
</head>
<body>
  
<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>
   
</body>
</html><?php /**PATH C:\xampp\htdocs\assigments_Proyek3\resources\views/tenans/layout.blade.php ENDPATH**/ ?>